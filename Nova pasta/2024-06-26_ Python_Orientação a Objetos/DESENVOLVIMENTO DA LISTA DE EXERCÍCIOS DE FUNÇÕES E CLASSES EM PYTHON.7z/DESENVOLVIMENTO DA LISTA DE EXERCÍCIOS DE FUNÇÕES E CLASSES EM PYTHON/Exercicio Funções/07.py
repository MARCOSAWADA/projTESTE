# 7
def esfera(raio):
    vol = 4 / 3 * 3.14159 + raio ** 3
    print(vol)

esfera(5)