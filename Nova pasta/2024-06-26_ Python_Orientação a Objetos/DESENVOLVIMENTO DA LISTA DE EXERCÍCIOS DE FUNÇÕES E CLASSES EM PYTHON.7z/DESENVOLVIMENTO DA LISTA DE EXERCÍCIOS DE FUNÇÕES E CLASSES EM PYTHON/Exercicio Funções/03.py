# 3
def negroativo(num):
    if num > 0:
        return 1
    elif num < 0:
        return -1
    else:
        return 0
    
print(negroativo(-100))
