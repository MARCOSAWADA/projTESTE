# 13
def exponente(num1, num2):
    resultado = 1
    for i in range(num2):
        resultado *= num1
    print(resultado)

exponente(3,3)
