# 5
def maior(num1,num2,num3):
    numeros = [num1,num2,num3]
    print(max(numeros))

maior(5,10,15)