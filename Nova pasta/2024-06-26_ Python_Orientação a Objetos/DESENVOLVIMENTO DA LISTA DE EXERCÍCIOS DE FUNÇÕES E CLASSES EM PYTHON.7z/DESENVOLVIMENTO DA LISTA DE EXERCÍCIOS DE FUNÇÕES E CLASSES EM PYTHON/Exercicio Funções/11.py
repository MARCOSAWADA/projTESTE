# 11

def calcular(num1, num2, operador):
    if operador == "+":
        print(f"{num1 + num2}")
    elif operador == "-":
        print(f"{num1 - num2}")
    elif operador == "*":
        print(f"{num1 * num2}")
    elif operador == "/":
        print(f"{num1 / num2}")
    else:
        print("erro sei la")

calcular(5,5, "+")

calcular(5,5, "-")

calcular(5,5, "*")

calcular(5,5, "/")
