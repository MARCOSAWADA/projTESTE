# 4
def horas(seg,min,horas):
    print(f"{seg + (min * 60) + ((horas * 60) * 60)}")

horas(10, 1, 1)
