# 1
def potencia(num1,num2):
    for i in range(num2 + 1):
        print(f"{num1 ** i}")

potencia(2,3)