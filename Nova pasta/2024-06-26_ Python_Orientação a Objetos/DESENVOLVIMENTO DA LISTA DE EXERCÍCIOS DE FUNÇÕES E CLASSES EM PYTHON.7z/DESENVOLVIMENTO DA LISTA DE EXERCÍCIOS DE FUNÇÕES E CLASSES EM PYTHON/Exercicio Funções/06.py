# 6
def reverso(num):
    num = str(num)
    invertido = "".join(reversed(num))
    print(invertido)

reverso(102)
