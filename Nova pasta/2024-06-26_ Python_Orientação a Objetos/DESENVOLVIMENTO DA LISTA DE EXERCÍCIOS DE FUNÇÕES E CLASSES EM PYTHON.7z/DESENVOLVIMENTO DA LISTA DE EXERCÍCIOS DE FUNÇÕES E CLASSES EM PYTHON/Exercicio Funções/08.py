# 8

def cilindro(alt,raio):
    volume = 3.141592 * (raio * raio) * alt
    print(volume)

cilindro(10,2)
