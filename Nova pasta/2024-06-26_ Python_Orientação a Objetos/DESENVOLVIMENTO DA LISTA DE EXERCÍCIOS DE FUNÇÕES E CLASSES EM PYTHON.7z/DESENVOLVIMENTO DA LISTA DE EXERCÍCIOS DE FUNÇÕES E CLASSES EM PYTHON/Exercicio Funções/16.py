# 16
def exclamacao(num):
    for i in range(num+1):
        print("!" * i)

exclamacao(5)