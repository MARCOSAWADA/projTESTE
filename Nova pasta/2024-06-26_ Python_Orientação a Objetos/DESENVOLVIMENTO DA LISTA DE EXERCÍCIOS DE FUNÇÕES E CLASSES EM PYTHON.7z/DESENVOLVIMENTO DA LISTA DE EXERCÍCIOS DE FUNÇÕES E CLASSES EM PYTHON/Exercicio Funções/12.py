# 12

def existentes(num1,num2):
    numeros = 0
    for i in range(num1, num2):
        numeros += i

    print(numeros)

existentes(1,5)