# 9

def convertertemp(temp):
    graus = (9 / 5) * temp + 32
    print(graus)

convertertemp(70)